@echo off
echo ================================================
echo  VCO Edge Exporter - Windows EXE Builder
echo ================================================
echo.

:: Check Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.9+ from python.org
    pause
    exit /b 1
)

echo [1/3] Installing dependencies...
pip install pyinstaller PyQt6 pandas openpyxl requests urllib3 --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

echo [2/3] Building EXE...
pyinstaller ^
  --onefile ^
  --windowed ^
  --name "VCO_Edge_Exporter" ^
  --hidden-import "openpyxl" ^
  --hidden-import "openpyxl.cell._writer" ^
  --hidden-import "pandas" ^
  --hidden-import "requests" ^
  --hidden-import "urllib3" ^
  --hidden-import "PyQt6" ^
  --hidden-import "PyQt6.QtCore" ^
  --hidden-import "PyQt6.QtGui" ^
  --hidden-import "PyQt6.QtWidgets" ^
  main.py

if errorlevel 1 (
    echo ERROR: PyInstaller build failed.
    pause
    exit /b 1
)

echo.
echo [3/3] Done!
echo.
echo  EXE is ready at: dist\VCO_Edge_Exporter.exe
echo.
echo  Double-click it to launch — no Python installation required.
echo.
pause

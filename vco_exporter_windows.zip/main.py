import json
import sys
import os
import threading
import urllib3
import requests
import pandas as pd
from datetime import datetime
from requests.structures import CaseInsensitiveDict

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QFileDialog,
    QFrame, QSizePolicy, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QColor, QPalette, QIcon

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()

# ── Palette ──────────────────────────────────────────────────────────────────
BG      = "#0f1117"
CARD    = "#1a1d27"
ACCENT  = "#00c7b7"
TEXT    = "#e8eaf0"
MUTED   = "#6b7280"
BORDER  = "#2a2d3a"
LOGBG   = "#0a0c12"
LOGTEXT = "#a0f0e8"
BTN_DIS = "#2a2d3a"

STYLE = f"""
QMainWindow, QWidget#root {{
    background: {BG};
}}
QWidget {{
    background: {BG};
    color: {TEXT};
    font-family: 'Courier New', monospace;
}}
QFrame#card {{
    background: {CARD};
    border: 1px solid {BORDER};
    border-radius: 6px;
}}
QLabel#header_vco {{
    color: {ACCENT};
    font-size: 22px;
    font-weight: bold;
}}
QLabel#header_title {{
    color: {TEXT};
    font-size: 22px;
}}
QLabel#header_sub {{
    color: {MUTED};
    font-size: 10px;
}}
QLabel#field_label {{
    color: {MUTED};
    font-size: 10px;
    font-weight: bold;
}}
QLineEdit {{
    background: #12151f;
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 8px 10px;
    font-size: 11px;
    font-family: 'Courier New', monospace;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus {{
    border: 1px solid {ACCENT};
}}
QPushButton#run_btn {{
    background: {ACCENT};
    color: #0f1117;
    font-size: 13px;
    font-weight: bold;
    font-family: 'Courier New', monospace;
    border: none;
    border-radius: 5px;
    padding: 13px;
}}
QPushButton#run_btn:hover {{
    background: #00a89a;
}}
QPushButton#run_btn:disabled {{
    background: {BTN_DIS};
    color: {MUTED};
}}
QPushButton#browse_btn {{
    background: #1e2233;
    color: {ACCENT};
    font-size: 10px;
    font-family: 'Courier New', monospace;
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 8px 14px;
}}
QPushButton#browse_btn:hover {{
    background: #252a3a;
}}
QTextEdit#log {{
    background: {LOGBG};
    color: {LOGTEXT};
    border: none;
    font-size: 10px;
    font-family: 'Courier New', monospace;
    padding: 6px;
}}
QLabel#divider {{
    background: {ACCENT};
    max-height: 2px;
    min-height: 2px;
}}
QLabel#log_header {{
    color: {MUTED};
    font-size: 9px;
    font-weight: bold;
}}
QLabel#status {{
    color: {MUTED};
    font-size: 9px;
}}
QScrollBar:vertical {{
    background: {CARD};
    width: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {BORDER};
    border-radius: 3px;
}}
"""

# ── Core logic ───────────────────────────────────────────────────────────────

def api_call(vco_url, token, method, params):
    headers = CaseInsensitiveDict()
    headers["Authorization"] = token
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    data = {"id": 0, "jsonrpc": "2.0", "method": method, "params": params}
    try:
        resp = requests.post(vco_url, headers=headers, data=json.dumps(data), verify=False, timeout=30)
        return resp.json()
    except Exception as e:
        return {"error": str(e)}

def get_enterprise_ids(vco_url, token):
    parsed = api_call(vco_url, token, "enterprise/getEnterprisesWithProperty",
                      {"name": "vco.enterprise.edgeImageManagement.enable", "value": "true"})
    return [{"id": i.get("id"), "name": i.get("name"), "logicalId": i.get("logicalId", "")}
            for i in parsed.get("result", [])]

def get_enterprise_details(vco_url, token, ent_id):
    return api_call(vco_url, token, "enterprise/getEnterprise",
                    {"id": ent_id, "with": ["enterpriseProxy"]})

def get_edges(vco_url, token, ent):
    params = {
        "enterpriseId": ent["id"],
        "with": ["site","ha","configuration","recentLinks","cloudServices",
                 "nvsFromEdge","vnfs","certificateSummary","secureDeviceSecrets"],
        "sortBy": [{"attribute": "edgeState", "type": "ASC"}],
        "_filterSpec": True
    }
    return api_call(vco_url, token, "enterprise/getEnterpriseEdgeList", params)

def get_edge_licenses(vco_url, token, ent_id):
    return api_call(vco_url, token, "license/getEnterpriseEdgeLicenses", {"enterpriseId": ent_id})

def safe_get(d, *keys):
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key, "")
        else:
            return ""
    return d if d is not None else ""

def format_date(date_string):
    if not date_string:
        return ""
    try:
        dt = datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.000Z")
        return dt.strftime("%m/%d/%y")
    except Exception:
        return date_string

def clean_vco_url(url):
    url = url.replace("https://","").replace("http://","")
    url = url.replace("/portal/","").replace("/portal","")
    return url.rstrip("/")

def normalize_vco_url(url):
    url = url.strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    url = url.rstrip("/")
    if "/portal/rest" not in url:
        url = url + "/portal/rest"
    return url


# ── Worker thread ─────────────────────────────────────────────────────────────

class ExportWorker(QObject):
    log     = pyqtSignal(str)
    done    = pyqtSignal(str, int)
    error   = pyqtSignal(str)

    def __init__(self, vco_url_raw, token, output_path):
        super().__init__()
        self.vco_url_raw = vco_url_raw
        self.token       = token
        self.output_path = output_path

    def run(self):
        try:
            vco_url = normalize_vco_url(self.vco_url_raw)
            cleaned = clean_vco_url(self.vco_url_raw)

            self.log.emit(f"Connecting to: {vco_url}")
            enterprises = get_enterprise_ids(vco_url, self.token)

            if not enterprises:
                self.error.emit("No enterprises found. Check your VCO URL and API token.")
                return

            self.log.emit(f"Found {len(enterprises)} enterprise(s)")
            output_rows = []

            for ent in enterprises:
                self.log.emit(f"  → {ent['name']} (id={ent['id']})")

                ent_details = get_enterprise_details(vco_url, self.token, ent["id"])
                partner_name = safe_get(ent_details.get("result", {}), "enterpriseProxy", "name")

                license_resp = get_edge_licenses(vco_url, self.token, ent["id"])
                licenses     = license_resp.get("result", [])
                lic_lookup   = {l.get("id"): l.get("sku","") for l in licenses if l.get("id") is not None}
                self.log.emit(f"    Licenses: {len(lic_lookup)}")

                edges     = get_edges(vco_url, self.token, ent)
                edge_data = edges.get("result", {}).get("data", [])
                self.log.emit(f"    Edges:    {len(edge_data)}")

                for edge in edge_data:
                    row = {
                        "Serial Number":        edge.get("serialNumber",""),
                        "Edge Logical ID":       edge.get("logicalId",""),
                        "Edge Status":           edge.get("edgeState",""),
                        "Edge Activation Date":  format_date(edge.get("activationTime","")),
                        "Type": "", "Name": edge.get("name",""), "Description": "",
                        "Country":  safe_get(edge,"site","country"),
                        "State":    safe_get(edge,"site","state"),
                        "City":     safe_get(edge,"site","city"),
                        "HA Serial Number": edge.get("haSerialNumber",""),
                        "Model Number":     edge.get("modelNumber",""),
                        "License":          lic_lookup.get(edge.get("id"),""),
                        "License Set By Maestro": "",
                        "VCO URL":              cleaned,
                        "VCO Enterprise Name":  ent["name"],
                        "Customer UUID":        ent["logicalId"],
                        "VCO Partner Name":     partner_name,
                        "Last Sync":"","Ship Date":"","RMA Date":"",
                        "Shipped Order Number":"","Configured BW Total MBPS":"",
                        "Bandwidth Over-utilized":"","License Tier Over-utilized":"",
                        "EFS":"","Calculated License":""
                    }
                    output_rows.append(row)

            if output_rows:
                df = pd.DataFrame(output_rows)
                df.to_excel(self.output_path, index=False)
                self.log.emit(f"\n✓ {len(output_rows)} edges written to:\n  {self.output_path}")
                self.done.emit(self.output_path, len(output_rows))
            else:
                self.error.emit("No edge data found.")

        except Exception as e:
            self.error.emit(f"Unexpected error: {e}")


# ── Main Window ───────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VCO Edge Exporter")
        self.setFixedSize(680, 600)
        self._thread = None
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(32, 24, 32, 16)
        layout.setSpacing(10)

        # ── Header row ──
        hdr = QHBoxLayout()
        lbl_vco = QLabel("VCO")
        lbl_vco.setObjectName("header_vco")
        lbl_title = QLabel(" Edge Exporter")
        lbl_title.setObjectName("header_title")
        lbl_sub = QLabel("VMware SD-WAN → Excel")
        lbl_sub.setObjectName("header_sub")
        hdr.addWidget(lbl_vco)
        hdr.addWidget(lbl_title)
        hdr.addStretch()
        hdr.addWidget(lbl_sub, alignment=Qt.AlignmentFlag.AlignBottom)
        layout.addLayout(hdr)

        # ── Divider ──
        div = QLabel()
        div.setObjectName("divider")
        layout.addWidget(div)

        # ── Form card ──
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(20, 14, 20, 14)
        card_layout.setSpacing(10)

        def add_field(label_text, placeholder="", password=False):
            card_layout.addWidget(self._label(label_text))
            entry = QLineEdit()
            entry.setPlaceholderText(placeholder)
            if password:
                entry.setEchoMode(QLineEdit.EchoMode.Password)
            card_layout.addWidget(entry)
            return entry

        self.url_entry   = add_field("VCO URL", "e.g. vco123.velocloud.net or https://vco123.velocloud.net/portal/rest")
        self.token_entry = add_field("API Token", "Token XXXXXX...", password=True)

        # Output path row
        card_layout.addWidget(self._label("Output File (.xlsx)"))
        out_row = QHBoxLayout()
        self.out_entry = QLineEdit()
        default_path = os.path.join(os.path.expanduser("~"), "Desktop", "edges_output.xlsx")
        self.out_entry.setText(default_path)
        browse = QPushButton("Browse")
        browse.setObjectName("browse_btn")
        browse.setFixedWidth(80)
        browse.clicked.connect(self._browse)
        out_row.addWidget(self.out_entry)
        out_row.addWidget(browse)
        card_layout.addLayout(out_row)

        layout.addWidget(card)

        # ── Run button ──
        self.run_btn = QPushButton("▶  EXPORT EDGES")
        self.run_btn.setObjectName("run_btn")
        self.run_btn.clicked.connect(self._start_export)
        layout.addWidget(self.run_btn)

        # ── Log frame ──
        log_frame = QFrame()
        log_frame.setObjectName("card")
        log_layout = QVBoxLayout(log_frame)
        log_layout.setContentsMargins(10, 8, 10, 8)
        log_layout.setSpacing(4)

        log_hdr = QLabel("OUTPUT LOG")
        log_hdr.setObjectName("log_header")
        log_layout.addWidget(log_hdr)

        self.log_text = QTextEdit()
        self.log_text.setObjectName("log")
        self.log_text.setReadOnly(True)
        log_layout.addWidget(self.log_text)
        layout.addWidget(log_frame, stretch=1)

        # ── Status bar ──
        self.status_lbl = QLabel("Ready")
        self.status_lbl.setObjectName("status")
        layout.addWidget(self.status_lbl)

    def _label(self, text):
        lbl = QLabel(text)
        lbl.setObjectName("field_label")
        return lbl

    def _browse(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Output File", "edges_output.xlsx",
            "Excel Files (*.xlsx)"
        )
        if path:
            self.out_entry.setText(path)

    def _log(self, msg):
        self.log_text.append(msg)

    def _start_export(self):
        url   = self.url_entry.get() if hasattr(self.url_entry, 'get') else self.url_entry.text().strip()
        token = self.token_entry.text().strip()
        out   = self.out_entry.text().strip()

        url = self.url_entry.text().strip()

        if not url:
            QMessageBox.critical(self, "Missing Field", "Please enter a VCO URL.")
            return
        if not token:
            QMessageBox.critical(self, "Missing Field", "Please enter an API Token.")
            return
        if not out:
            QMessageBox.critical(self, "Missing Field", "Please select an output file path.")
            return

        self.run_btn.setEnabled(False)
        self.run_btn.setText("⏳  Exporting...")
        self.log_text.clear()
        self.status_lbl.setText("Running export…")

        self._thread = QThread()
        self._worker = ExportWorker(url, token, out)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.log.connect(self._log)
        self._worker.done.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.done.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.start()

    def _on_done(self, path, count):
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶  EXPORT EDGES")
        self.status_lbl.setText(f"✓ {count} edges exported → {path}")
        QMessageBox.information(self, "Export Complete",
                                f"{count} edges exported successfully!\n\n{path}")

    def _on_error(self, msg):
        self._log(f"ERROR: {msg}")
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶  EXPORT EDGES")
        self.status_lbl.setText("✗ Export failed")
        QMessageBox.critical(self, "Export Failed", msg)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

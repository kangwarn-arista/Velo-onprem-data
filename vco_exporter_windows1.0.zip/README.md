# VCO Edge Exporter

Export VMware SD-WAN edge data to Excel with a simple GUI.

---

## How to build the Windows EXE

**Requirements:** Windows PC with Python 3.9+ installed  
(download from https://python.org — check "Add to PATH" during install)

**Steps:**

1. Copy both files to a folder on your Windows PC:
   - `main.py`
   - `build_windows.bat`

2. Double-click `build_windows.bat`

3. Wait ~60 seconds for it to install dependencies and build

4. Your EXE will appear at: `dist\VCO_Edge_Exporter.exe`

5. Copy `VCO_Edge_Exporter.exe` anywhere — no Python needed to run it

---

## Using the app

1. **VCO URL** — enter your VCO hostname or full URL, e.g.:
   - `vco123.velocloud.net`
   - `https://vco123.velocloud.net`
   - `https://vco123.velocloud.net/portal/rest`

2. **API Token** — your VCO API token (the field is masked)

3. **Output File** — choose where to save the Excel file (defaults to Desktop)

4. Click **EXPORT EDGES** — progress logs appear in real time

5. A popup confirms success with the file path

---

## Output columns

Serial Number, Edge Logical ID, Edge Status, Edge Activation Date, Name,
Country, State, City, HA Serial Number, Model Number, License, VCO URL,
VCO Enterprise Name, Customer UUID, VCO Partner Name, and more.

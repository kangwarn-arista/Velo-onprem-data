import json
import sys
import os
import base64
import threading
import urllib3
import requests
import pandas as pd
from datetime import datetime
from requests.structures import CaseInsensitiveDict

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QFileDialog,
    QFrame, QSizePolicy, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QColor, QPalette, QIcon, QPixmap

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()

ARISTA_LOGO_B64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCACUAKUDASIAAhEBAxEB/8QAHAABAAMBAQEBAQAAAAAAAAAAAAUGBwQDCAIB/8QASBAAAQMEAQIDBAQJCAkFAAAAAQACAwQFBhEHEiETMUEIFCJRFTJhcRgjQlJVYoGT0hYXOFRzkZWzJDQ3VmNydZahsbLC0dT/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAgMBBAb/xAArEQACAgEDAgQHAAMAAAAAAAAAAQIRAxIhMUFREyKBwQQUUmGRsdFxofH/2gAMAwEAAhEDEQA/AMEREX1B86EREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREARFbuLOO8j5Hvc9rx9tMz3aLxamoqXlsUQJIaCQCSXEHQA9D8lyUlFW+CoxcnSKiikcnsdzxrIa6w3mnNPX0MpimZvYPyc0+rSNEH1BC/mMWioyDJLZYaSSKKouNXHSxPk30Nc9waCdd9d0tVZyndEei3z8FTPf03j37yX+BPwVM9/TePfvJf4Fh81h+o2+Wy/SYGiufKPGOW8cVcEeR0sBpqlxbTVlLIXwyuA2W7IBa7XfRA8jrYBK9rrxhfbbxRQ8kT1lvNqrXRtjga5/jjreWjY6enzHz9Vr4kGk75I8OdtVwUZFonF3DWbch0DrnZ4KOktYe5grK2UsZI5p04MDQXO0exOgPMb2CFePwVM9/TePfvJf4FEviMUXTkVHBkkrSMDRavyTwVkWAYrPkV+v1j93je2OOKF0plmkcdBjAWjv5k+gAJPkuzCvZzzzJ8Zor9HU2u2w1sfiww1b5BL4Z+q4gNOtjuB8iE+Yx6dV7HPAyXVbmOIt8/BUz39N49+8l/gVW5P4Myrj7FXZFd7laamlbPHAWUzpC/bzoH4mgaSPxGKTpSOvBkStoyxFdOKeMsm5Krq6nx9tLFHQxtdUVFU9zI2udvpYCGklx0e2uw7n03Vr3bK6y3mss90p3U1dRTOgqInebHtPf7x6g+oIPqtFOLbinuZuEktTWxyIiKiQiIgCIiA9aOlqq6shoqGnkqaqokbFDDGNuke46a0faSV9PZfeIPZ04ituK2WqpP5bXpwq6udzQ8M1rxHny2wa8Nm/PufQqB9l/E7Zj9kuHM+ZD3e2WtjxbPEbvrOul0zR6kl3hsHmXF2vySvaX2scjdK5zMLs4YSegPq5C4N32B+HzXizOWWemKtLnpue3Eo4oapOm+Dq5ptdv5f4kt3L+MwgXa3U5ivFJFpxLW6MjT22TEduB9WOPby1inDZB5dw0juPpuk/wA1q0jiTnC6wcx1l2yudhs+SSNp62EEmGjA22FzGn8lu+l3qQSTsjS98s44PH3tL4gaBhNgu18p6m3OA+GL8c0vh2O3wlw6f1SPPRKQbxp4pdtv56CaWRrJHvv/AE6/ads17yX2io7DY66OGsqLRTeBFNXe7tld1y/C0kgFx9B5nSrv4P3NP9TZ/jLf4l7+2cXN5yLmuc1zbTSua5p0WkPlIII8ir1wvzBHnGPu44zq911qus8Yht18pKl1PNK78kF7fKUHWt/C/WiCToypZIYYyhxW5Uo455ZRlyePNcFdh/stWXC81u0dyymesY6AeKZnsY2Z0n13fEQyMiPqPqQPVeOe/wBBrGf7Sk/znLIeasKzDDMwlgy2rrbqag/6Jd55nyisjA/OcSQ5u9FhPb020gnXs9/oN4z/AGlJ/nOXHFRUGndys7rcpTtVSJens125Q9mLF7Nx1e4KKrtZjhudEal8Ae5jHNcx7mgu+sQ8AjTux+RWf/g5cx/1q2/4zL/AqPxzgvKF/pZb3gFru7oo5DTyVlDc46I9QAJaHOljc7Wx5bA+9XD+br2nPzc3/wC8Y/8A9auvDbUZr15/YSWRJyi/QgeQuHOTMRsz7vf6AVltgHVNUU1aahsA8tuadOA+0AgepCz4VtcAAK+sAHkBUPAH/lfXXCVp5BwzC8vuPMFxrWWY034umutzbWyD4XB7usPfprgWtDerufQevx6zQYNAga8j6LXBkc3JOnXVGGfGoU116M+nuR6mpHsVYpM2pmErpKTcgkIcfif6+a+cbZTXe/XWjs9EamurKyZsNPC6Vzup7joee9D1J9ACV9E8kf0JMS/tKT/3PXN7OOPW3AcGufNeXxBrI6dzLNCfrua74epv68jtMb8m7Pk7thiyLHjk+tujXJB5JxXSlZLcg5ZTez1x9YMDxaelnyaoc2uuNQ8DRAcC9zh/xCDG0ejGn1AJifaHsds5G47tnNmIxA6pw28wDXU1jexc7X5UTgWuPq3R8m9/D8LHJieo4ZZdn51Uh/8Aio/grmOpHKF1gzSZk9oy+oDKmN7eqGmmd+LjAad6jLemM77aDSfIlTHFlgtenzLd789y3kxzei9n9uDB0Wgc98eT8c59PbYmPNnrOqotcpO9xbHVGT+cwnp+7pPqs/XvhJTipLhnglFxbiwiIqJCIiAmrjl2UXLH6fHq6/19RZ6YMENE6T8SzoGm/CPl6b+/zUKtEy+02q6cOYtmlloaelqKKV9kvjIIw0PnaA+KV2vynMPc9yepvyUJxJjYy3kmx2GVpNNNU+JVn0bBGDJISfQdLSPvcB6rNTiot1VWayhJyS5sqpAI0e4KsU+c5nPTW6mnye6TQ2uSOWgbJN1+7Pj+o5hPcEeW103qjqM25Hu0WEY4XwT1choKG3U+msp2HpY7Q7N20BxJ7bcVy5ZhOXYnHDLkmPV1simJbHLIGujcR6dbCW7+ze124ulLnsc0yVtcHBkV9vORXM3O/XOpuVaY2x+PUO6n9Dd6bv5DZ/vUd/ePUEeivtFa7c/2d7ne3UNObnHlMVMyqLB4jYTTtcWB3n07O9fNVvFcUyXK6iWDG7HWXSSEdUvgtHTGP1nuIa39pCRlGn0SOOMm11bPe+5tmF+tEdoveS3K5UEbmuZBVS+IGlvZpBI3sDtve+5+a56nKslqcZhxmovldLZIC0xULpNxM0djQ+w90yrFckxWpipskslZa5JhuLx2DpkH6rwS137CVauPbBjtBiFdyLmlM+vtlNVCgtVqZIY/pGtLesh7xsiNrQSfnr7NOluEY2l+O5SU3Kr/AOEJYuQ86sNrhtVlyy6W6hh6vCp6eQNYzqcXHQ16kkn7Su7+drk//fy+/vx/9Luj5TBnLazjbjyot57Oo47K2E9PybMCXtd+t3+4qL5psWP2d9DecPq3Psd7txraanklD56KQdpIX+vwkt0T3OyPTZ4oxcqlFb/4K81XGRGZNmOW5NFHDkOTXW6QxnbIqipc6MH59H1d/brag1fvaItlssfMN/ttqoqagoYHx+HBAwMjYDE0nQHYdySuG3cW8j3G2MuVFhd3mpJGdbH+G1rnt+bWOIe4fc0qozgoJ8JkyhNya5aIasyjJKzHIMbq75XT2an6fBoXy7hj6d6037Nlel6y7Kb3aKW0Xa/19ZbqTp93pZJPxUXS3pbpoAHYdh8lEinqDWe5eBKKrxfB8EsIeJN9PQWnuHb7a89r0ulBW2u41FuuVLLSVlM/w5oJW9L43fIj0KrTG+CLlXJzL+EbGj6rsrrbcKGmoqmtop6eGvh8ekkkZoTx711N+Y32U5jPHucZNbfpKw4vcK+iLi1s7Q1jHkdiGl5HWdg9m7XXJJW2FFt0kceRZdlGRUVLRX6/19zpqR3VTx1MnWIj09PY635dvNQi0O/Y9FauC4amvs/uV+hzA0VS+aDoqGR+5yP8J2xsN2Gu19xWeKYNNeUqcZJrUERFZmEREBp3Bro8hoco4xqXkfyjofHtv6tfTbmj194ad+WwzR8047dLinEmZZm9pp7hcS3HLW49nNdJp1S5p89tZrRH5TfsVDxa81eO5Lbb/Q/6zb6plRGN66uk7Lf2jY/arzzvm+O5TVWy34bS1VFYaN9TWOhmZ4ZfV1Mpkld0gkaHYN+QLgvPOL10uHz6f3Y9MJrRbe649f4WDCrNBD7Ovi0mW2fFqnIbxJDW1ddM6J0tPA0htOxzBvRO3EeoLvQr9YTQY9YrHklkv3LOJXCx3a2yx+6RVr3uZVgbgmjDhoPDvUdz23vQVMwnJrBJhddgeZiujtE1WK+33CjjEk1uqQ3pcegkdcbxoFo0e7teexIU13wPCrJeHYtdK/JcgulG+hhq6m3e6QW+J/aR7WuLnPkI7A+Q/v3EoStrfd9vf7GkJxpPsu/sfm2En2Wbo5w0TmEBI+R91aujlCsqLHxpx9itrmkpaCtssd6r/CcWisqZ/i28j64YOwB7Dt8hqv0eR22HhKuw4if6SmyCO4R6Z+L8FsIYfi357HlpSluyLEsmwm04xm9TcrTW2Jr4rXeKSmFSHU7nb8CaLYcQ0/VLT2AH2g3padtbX7GakmqT3r3Ovi+uqMg4/wA5w27SOq7fRWaS+W8zu6vcqmB7ATGT9XrEhBA89H847/GTAy+zJg0kXeOmv9xp6kj0meXyRg/b4YP7Aua45FimM4Rc8Yweor7rW3zpjut5rKb3Ye7sJIghi2SASfic47Pf7OmP46zSksVBcsbyS1OvWLXfpNZSMeGTQyt+pPC49mvb8vXQ7jXdpb8yXW/9UFJLyt9OSmKRyjGLrZ8Pt1/rooIqS+U88lFqTcj2R/CXObrsNka+YIV0is/CsFQKqfNsrrqRp6vo+OzCKokA8mmbq6BvyJAH2a81X+Wcumzm6+PBb4rXbaSjFBardG7bKWBoPSN+riTtx9ew9AtYzbkqWxGiMd2/wbBkVrobx7a7qO407amlbUe8vgcNiUw0Rla3R89uY3ssTyLK8hv+S1OSXC7V30lPMZWysnewwd9tbHo/A1vYADy181bs35GZLzvLyPiok6YqmOembVM6C8CMMc1wBOg4dQ+4r9XOm4avN1lvTMhyOwU9S/xprLHahO+Fx7uZDOHdAbsnp6h2H7AscacKcl0SNJvVai+rJTkl30reuLcyqI423PIKWmfcXMb0+NNBUMj8Yj854I3/AMqrHPX+2vMP+qP/APRq5uQM0dkWTW+vtVvba7bZYIaWzUbndfgwwu6mF5Hm5x7u192zrZtGa1/FubZBUZjXZDfrFXXAMluFphtfvB8YNDX+DN1BoB12Lh2PfXokE4U2uj/ZybU00n19jz5CpGV1j4eoJiWx1Vkihed6019T0k7+4ri9oO8VlRyjdLLG+WltVhe222yijcWxU8UTGt+Fo7AuILtgeRHyC8uW80tGUx4n/J+imtbLJbTRMgPfwAyU+CA78shgZt3q7akcku/HvINXHkuQ3m54vkUsLGXWOntnvlPWSMaGCaPpe0sc4AbDu3Yd/MlBONNrv+zsmpakn2/R3ZjfrhfvZbx2S6zSVVVR5X7r71KS6SaNtJOWdbj3cWh3Ts99ALIVpWd5lildxLbcExmhr6eG1XwVcUtWAZauMwStfNIW/C17pJOzB2DQO/oM1WmJUntW7Izu2t72CIi1MAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA//9k="

# ── Palette ──────────────────────────────────────────────────────────────────
BG      = "#0f1117"
CARD    = "#1a1d27"
ACCENT  = "#00c7b7"
TEXT    = "#e8eaf0"
MUTED   = "#6b7280"
BORDER  = "#2a2d3a"
LOGBG   = "#0a0c12"
LOGTEXT = "#a0f0e8"
BTN_DIS = "#2a2d3a"

STYLE = f"""
QMainWindow, QWidget#root {{
    background: {BG};
}}
QWidget {{
    background: {BG};
    color: {TEXT};
    font-family: 'Courier New', monospace;
}}
QFrame#card {{
    background: {CARD};
    border: 1px solid {BORDER};
    border-radius: 6px;
}}
QLabel#header_vco {{
    color: {ACCENT};
    font-size: 22px;
    font-weight: bold;
}}
QLabel#header_title {{
    color: {TEXT};
    font-size: 20px;
    font-weight: bold;
}}
QLabel#header_sub {{
    color: {MUTED};
    font-size: 10px;
}}
QLabel#field_label {{
    color: {MUTED};
    font-size: 10px;
    font-weight: bold;
}}
QLineEdit {{
    background: #12151f;
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 8px 10px;
    font-size: 11px;
    font-family: 'Courier New', monospace;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus {{
    border: 1px solid {ACCENT};
}}
QPushButton#run_btn {{
    background: {ACCENT};
    color: #0f1117;
    font-size: 13px;
    font-weight: bold;
    font-family: 'Courier New', monospace;
    border: none;
    border-radius: 5px;
    padding: 13px;
}}
QPushButton#run_btn:hover {{
    background: #00a89a;
}}
QPushButton#run_btn:disabled {{
    background: {BTN_DIS};
    color: {MUTED};
}}
QPushButton#browse_btn {{
    background: #1e2233;
    color: {ACCENT};
    font-size: 10px;
    font-family: 'Courier New', monospace;
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 8px 14px;
}}
QPushButton#browse_btn:hover {{
    background: #252a3a;
}}
QTextEdit#log {{
    background: {LOGBG};
    color: {LOGTEXT};
    border: none;
    font-size: 10px;
    font-family: 'Courier New', monospace;
    padding: 6px;
}}
QLabel#divider {{
    background: {ACCENT};
    max-height: 2px;
    min-height: 2px;
}}
QLabel#log_header {{
    color: {MUTED};
    font-size: 9px;
    font-weight: bold;
}}
QLabel#status {{
    color: {MUTED};
    font-size: 9px;
}}
QScrollBar:vertical {{
    background: {CARD};
    width: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {BORDER};
    border-radius: 3px;
}}
"""

# ── Core logic ───────────────────────────────────────────────────────────────

def api_call(vco_url, token, method, params):
    headers = CaseInsensitiveDict()
    headers["Authorization"] = token
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    data = {"id": 0, "jsonrpc": "2.0", "method": method, "params": params}
    try:
        resp = requests.post(vco_url, headers=headers, data=json.dumps(data), verify=False, timeout=30)
        return resp.json()
    except Exception as e:
        return {"error": str(e)}

def get_enterprise_ids(vco_url, token):
    parsed = api_call(vco_url, token, "enterprise/getEnterprisesWithProperty",
                      {"name": "vco.enterprise.edgeImageManagement.enable", "value": "true"})
    return [{"id": i.get("id"), "name": i.get("name"), "logicalId": i.get("logicalId", "")}
            for i in parsed.get("result", [])]

def get_enterprise_details(vco_url, token, ent_id):
    return api_call(vco_url, token, "enterprise/getEnterprise",
                    {"id": ent_id, "with": ["enterpriseProxy"]})

def get_edges(vco_url, token, ent):
    params = {
        "enterpriseId": ent["id"],
        "with": ["site","ha","configuration","recentLinks","cloudServices",
                 "nvsFromEdge","vnfs","certificateSummary","secureDeviceSecrets"],
        "sortBy": [{"attribute": "edgeState", "type": "ASC"}],
        "_filterSpec": True
    }
    return api_call(vco_url, token, "enterprise/getEnterpriseEdgeList", params)

def get_edge_licenses(vco_url, token, ent_id):
    return api_call(vco_url, token, "license/getEnterpriseEdgeLicenses", {"enterpriseId": ent_id})

def safe_get(d, *keys):
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key, "")
        else:
            return ""
    return d if d is not None else ""

def format_date(date_string):
    if not date_string:
        return ""
    try:
        dt = datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.000Z")
        return dt.strftime("%m/%d/%y")
    except Exception:
        return date_string

def clean_vco_url(url):
    url = url.replace("https://","").replace("http://","")
    url = url.replace("/portal/","").replace("/portal","")
    return url.rstrip("/")

def normalize_vco_url(url):
    """
    Accept any of these from the user:
      veco315-yssy1.velocloud.net
      https://veco315-yssy1.velocloud.net
      https://veco315-yssy1.velocloud.net/portal/
      https://veco315-yssy1.velocloud.net/portal/rest
    Always returns: https://<fqdn>/portal/rest
    """
    url = url.strip()
    # Strip scheme so we can rebuild cleanly
    url = url.replace("https://", "").replace("http://", "")
    # Grab just the hostname (everything before first /)
    fqdn = url.split("/")[0]
    return f"https://{fqdn}/portal/"


# ── Worker thread ─────────────────────────────────────────────────────────────

class ExportWorker(QObject):
    log     = pyqtSignal(str)
    done    = pyqtSignal(str, int)
    error   = pyqtSignal(str)

    def __init__(self, vco_url_raw, token, output_path):
        super().__init__()
        self.vco_url_raw = vco_url_raw
        self.token       = token
        self.output_path = output_path

    def run(self):
        try:
            vco_url = normalize_vco_url(self.vco_url_raw)
            cleaned = clean_vco_url(self.vco_url_raw)

            # Auto-prepend "Token " if user pasted just the raw token
            token = self.token.strip()
            if not token.lower().startswith("token "):
                token = "Token " + token

            self.log.emit(f"Connecting to: {vco_url}")
            enterprises = get_enterprise_ids(vco_url, token)

            if not enterprises:
                self.error.emit("No enterprises found. Check your VCO URL and API token.")
                return

            self.log.emit(f"Found {len(enterprises)} enterprise(s)")
            output_rows = []

            for ent in enterprises:
                self.log.emit(f"  → {ent['name']} (id={ent['id']})")

                ent_details = get_enterprise_details(vco_url, token, ent["id"])
                partner_name = safe_get(ent_details.get("result", {}), "enterpriseProxy", "name")

                license_resp = get_edge_licenses(vco_url, token, ent["id"])
                licenses     = license_resp.get("result", [])
                lic_lookup   = {l.get("id"): l.get("sku","") for l in licenses if l.get("id") is not None}
                self.log.emit(f"    Licenses: {len(lic_lookup)}")

                edges     = get_edges(vco_url, token, ent)
                edge_data = edges.get("result", {}).get("data", [])
                self.log.emit(f"    Edges:    {len(edge_data)}")

                for edge in edge_data:
                    row = {
                        "Serial Number":        edge.get("serialNumber",""),
                        "Edge Logical ID":       edge.get("logicalId",""),
                        "Edge Status":           edge.get("edgeState",""),
                        "Edge Activation Date":  format_date(edge.get("activationTime","")),
                        "Type": "", "Name": edge.get("name",""), "Description": "",
                        "Country":  safe_get(edge,"site","country"),
                        "State":    safe_get(edge,"site","state"),
                        "City":     safe_get(edge,"site","city"),
                        "HA Serial Number": edge.get("haSerialNumber",""),
                        "Model Number":     edge.get("modelNumber",""),
                        "License":          lic_lookup.get(edge.get("id"),""),
                        "License Set By Maestro": "",
                        "VCO URL":              cleaned,
                        "VCO Enterprise Name":  ent["name"],
                        "Customer UUID":        ent["logicalId"],
                        "VCO Partner Name":     partner_name,
                        "Last Sync":"","Ship Date":"","RMA Date":"",
                        "Shipped Order Number":"","Configured BW Total MBPS":"",
                        "Bandwidth Over-utilized":"","License Tier Over-utilized":"",
                        "EFS":"","Calculated License":""
                    }
                    output_rows.append(row)

            if output_rows:
                df = pd.DataFrame(output_rows)
                df.to_excel(self.output_path, index=False)
                self.log.emit(f"\n✓ {len(output_rows)} edges written to:\n  {self.output_path}")
                self.done.emit(self.output_path, len(output_rows))
            else:
                self.error.emit("No edge data found.")

        except Exception as e:
            self.error.emit(f"Unexpected error: {e}")


# ── Main Window ───────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VCO Edge Exporter")
        self.setFixedSize(680, 600)
        self._thread = None
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(32, 24, 32, 16)
        layout.setSpacing(10)

        # ── Header row ──
        hdr = QHBoxLayout()
        hdr.setSpacing(14)

        # Arista logo
        logo_lbl = QLabel()
        logo_pixmap = QPixmap()
        logo_pixmap.loadFromData(base64.b64decode(ARISTA_LOGO_B64))
        logo_pixmap = logo_pixmap.scaledToHeight(52, Qt.TransformationMode.SmoothTransformation)
        logo_lbl.setPixmap(logo_pixmap)
        logo_lbl.setFixedSize(logo_pixmap.size())
        hdr.addWidget(logo_lbl, alignment=Qt.AlignmentFlag.AlignVCenter)

        # Title text
        title_col = QVBoxLayout()
        title_col.setSpacing(0)
        lbl_title = QLabel("Edge Exporter")
        lbl_title.setObjectName("header_title")
        lbl_sub = QLabel("SD-WAN → Excel")
        lbl_sub.setObjectName("header_sub")
        title_col.addWidget(lbl_title)
        title_col.addWidget(lbl_sub)
        hdr.addLayout(title_col)

        hdr.addStretch()
        layout.addLayout(hdr)

        # ── Divider ──
        div = QLabel()
        div.setObjectName("divider")
        layout.addWidget(div)

        # ── Form card ──
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(20, 14, 20, 14)
        card_layout.setSpacing(10)

        def add_field(label_text, placeholder="", password=False):
            card_layout.addWidget(self._label(label_text))
            entry = QLineEdit()
            entry.setPlaceholderText(placeholder)
            if password:
                entry.setEchoMode(QLineEdit.EchoMode.Password)
            card_layout.addWidget(entry)
            return entry

        self.url_entry   = add_field("VCO URL (FQDN)", "e.g. veco315-yssy1.velocloud.net")
        self.token_entry = add_field("API Token", "Paste your token here (no need to add 'Token ')", password=True)

        # Output path row
        card_layout.addWidget(self._label("Output File (.xlsx)"))
        out_row = QHBoxLayout()
        self.out_entry = QLineEdit()
        default_path = os.path.join(os.path.expanduser("~"), "Desktop", "edges_output.xlsx")
        self.out_entry.setText(default_path)
        browse = QPushButton("Browse")
        browse.setObjectName("browse_btn")
        browse.setFixedWidth(80)
        browse.clicked.connect(self._browse)
        out_row.addWidget(self.out_entry)
        out_row.addWidget(browse)
        card_layout.addLayout(out_row)

        layout.addWidget(card)

        # ── Run button ──
        self.run_btn = QPushButton("▶  EXPORT EDGES")
        self.run_btn.setObjectName("run_btn")
        self.run_btn.clicked.connect(self._start_export)
        layout.addWidget(self.run_btn)

        # ── Log frame ──
        log_frame = QFrame()
        log_frame.setObjectName("card")
        log_layout = QVBoxLayout(log_frame)
        log_layout.setContentsMargins(10, 8, 10, 8)
        log_layout.setSpacing(4)

        log_hdr = QLabel("OUTPUT LOG")
        log_hdr.setObjectName("log_header")
        log_layout.addWidget(log_hdr)

        self.log_text = QTextEdit()
        self.log_text.setObjectName("log")
        self.log_text.setReadOnly(True)
        log_layout.addWidget(self.log_text)
        layout.addWidget(log_frame, stretch=1)

        # ── Status bar ──
        self.status_lbl = QLabel("Ready")
        self.status_lbl.setObjectName("status")
        layout.addWidget(self.status_lbl)

    def _label(self, text):
        lbl = QLabel(text)
        lbl.setObjectName("field_label")
        return lbl

    def _browse(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Output File", "edges_output.xlsx",
            "Excel Files (*.xlsx)"
        )
        if path:
            self.out_entry.setText(path)

    def _log(self, msg):
        self.log_text.append(msg)

    def _start_export(self):
        url   = self.url_entry.get() if hasattr(self.url_entry, 'get') else self.url_entry.text().strip()
        token = self.token_entry.text().strip()
        out   = self.out_entry.text().strip()

        url = self.url_entry.text().strip()

        if not url:
            QMessageBox.critical(self, "Missing Field", "Please enter a VCO URL.")
            return
        if not token:
            QMessageBox.critical(self, "Missing Field", "Please enter an API Token.")
            return
        if not out:
            QMessageBox.critical(self, "Missing Field", "Please select an output file path.")
            return

        self.run_btn.setEnabled(False)
        self.run_btn.setText("⏳  Exporting...")
        self.log_text.clear()
        self.status_lbl.setText("Running export…")

        self._thread = QThread()
        self._worker = ExportWorker(url, token, out)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.log.connect(self._log)
        self._worker.done.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.done.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.start()

    def _on_done(self, path, count):
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶  EXPORT EDGES")
        self.status_lbl.setText(f"✓ {count} edges exported → {path}")
        QMessageBox.information(self, "Export Complete",
                                f"{count} edges exported successfully!\n\n{path}")

    def _on_error(self, msg):
        self._log(f"ERROR: {msg}")
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶  EXPORT EDGES")
        self.status_lbl.setText("✗ Export failed")
        QMessageBox.critical(self, "Export Failed", msg)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

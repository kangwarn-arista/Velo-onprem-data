@echo off
echo ================================================
echo  VCO Edge Exporter - Windows EXE Builder
echo ================================================
echo.

:: ── Find Python ──────────────────────────────────────────────────────────────
set PYTHON=
set PIP=

:: Try 'python' first
python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=python
    goto :find_pip
)

:: Try 'python3'
python3 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=python3
    goto :find_pip
)

:: Try common install paths
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
    "C:\Python39\python.exe"
) do (
    if exist %%P (
        set PYTHON=%%~P
        goto :find_pip
    )
)

echo ERROR: Python not found.
echo.
echo Please install Python from https://python.org
echo IMPORTANT: During install, check "Add Python to PATH"
echo.
pause
exit /b 1

:: ── Find pip ─────────────────────────────────────────────────────────────────
:find_pip

:: Prefer 'python -m pip' which always works if Python is found
%PYTHON% -m pip --version >nul 2>&1
if not errorlevel 1 (
    set PIP=%PYTHON% -m pip
    goto :install
)

echo ERROR: pip not found (Python was found but pip is missing).
echo.
echo Try running this in a terminal:
echo   %PYTHON% -m ensurepip --upgrade
echo.
pause
exit /b 1

:: ── Install deps ──────────────────────────────────────────────────────────────
:install
echo Python : %PYTHON%
echo pip    : %PIP%
echo.
echo [1/3] Installing dependencies (this may take a minute)...
echo.
%PIP% install pyinstaller PyQt6 pandas openpyxl requests urllib3 --quiet --disable-pip-version-check
if errorlevel 1 (
    echo.
    echo ERROR: Dependency install failed. Check your internet connection.
    pause
    exit /b 1
)

:: ── Build ─────────────────────────────────────────────────────────────────────
echo [2/3] Building EXE...
echo.
%PYTHON% -m PyInstaller ^
  --onefile ^
  --windowed ^
  --name "VCO_Edge_Exporter" ^
  --hidden-import "openpyxl" ^
  --hidden-import "openpyxl.cell._writer" ^
  --hidden-import "pandas" ^
  --hidden-import "requests" ^
  --hidden-import "urllib3" ^
  --hidden-import "PyQt6" ^
  --hidden-import "PyQt6.QtCore" ^
  --hidden-import "PyQt6.QtGui" ^
  --hidden-import "PyQt6.QtWidgets" ^
  main.py

if errorlevel 1 (
    echo.
    echo ERROR: Build failed. See output above for details.
    pause
    exit /b 1
)

:: ── Done ──────────────────────────────────────────────────────────────────────
echo.
echo [3/3] Done!
echo.
echo  Your EXE is ready at:
echo    %~dp0dist\VCO_Edge_Exporter.exe
echo.
echo  You can copy that EXE anywhere - no Python needed to run it.
echo.
pause
